﻿using System.Windows.Controls;

namespace WpfApp1.Pages;

/// <summary>
///     LevelPage.xaml 的交互逻辑
/// </summary>
public partial class LevelPage : Page
{
    public LevelPage()
    {
        InitializeComponent();
    }
}