﻿using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
namespace WpfApp1.Pages;

/// <summary>
///     DefaultPage.xaml 的交互逻辑
/// </summary>
public partial class DefaultPage : Page
{
	public DefaultPage()
	{
		InitializeComponent();
	}
}
